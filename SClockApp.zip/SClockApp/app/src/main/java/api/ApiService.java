package api;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface ApiService {

    @POST("/api/auth/login")
    Call<LoginResponse> login(@Body LoginRequest request);

    @POST("/api/auth/register")
    Call<LoginResponse> register(@Body LoginRequest request);

    @POST("/api/auth/forgot-password")
    Call<LoginResponse> forgotPassword(@Body ForgotPasswordRequest request);

    @GET("/api/users/{userId}")
    Call<String> getUser(@Path("userId") int userId);

    @GET("/api/tasks/user/{userId}")
    Call<String> getUserTasks(@Path("userId") int userId);

    @POST("/api/tasks")
    Call<String> createTask(@Body String task);

    @DELETE("/api/tasks/{taskId}")
    Call<String> deleteTask(@Path("taskId") int taskId);

    @GET("/api/locations/user/{userId}")
    Call<String> getUserLocations(@Path("userId") int userId);

    @GET("/api/restricted-apps/user/{userId}")
    Call<String> getUserRestrictedApps(@Path("userId") int userId);
}