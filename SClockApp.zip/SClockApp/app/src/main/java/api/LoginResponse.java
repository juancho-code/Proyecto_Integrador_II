package api;

import com.google.gson.annotations.SerializedName;

public class LoginResponse {
    @SerializedName("success")
    public boolean success;

    @SerializedName("message")
    public String message;

    @SerializedName("userId")
    public int userId;

    @SerializedName("email")
    public String email;

    @SerializedName("name")
    public String name;

    @SerializedName("token")
    public String token;

    public LoginResponse() {}

    public LoginResponse(boolean success, String message, int userId, String email, String name, String token) {
        this.success = success;
        this.message = message;
        this.userId = userId;
        this.email = email;
        this.name = name;
        this.token = token;
    }
}