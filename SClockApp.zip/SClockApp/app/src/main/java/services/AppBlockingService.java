package services;

import android.app.Service;
import android.app.usage.UsageStatsManager;
import android.content.Intent;
import android.os.IBinder;

import androidx.annotation.Nullable;

import java.util.Timer;
import java.util.TimerTask;

import data.db.SClockDatabase;
import utils.NotificationsUtils;

public class AppBlockingService extends Service {

    private Timer timer;
    private SClockDatabase database;
    private UsageStatsManager usageStatsManager;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        database = SClockDatabase.getInstance(this);
        usageStatsManager = (UsageStatsManager) getSystemService(USAGE_STATS_SERVICE);
        startAppMonitoring();
        return START_STICKY;
    }

    private void startAppMonitoring() {
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                checkBlockedApps();
            }
        }, 0, 5000);
    }

    private void checkBlockedApps() {
        try {
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (timer != null) {
            timer.cancel();
        }
    }
}
