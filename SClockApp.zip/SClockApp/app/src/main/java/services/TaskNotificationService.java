package services;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

import androidx.annotation.Nullable;

import java.util.Timer;
import java.util.TimerTask;

import data.db.SClockDatabase;
import data.models.Task;
import utils.DateTimeUtils;
import utils.NotificationsUtils;

public class TaskNotificationService extends Service {

    private Timer timer;
    private SClockDatabase database;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        database = SClockDatabase.getInstance(this);
        startTaskReminders();
        return START_STICKY;
    }

    private void startTaskReminders() {
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                checkUpcomingTasks();
            }
        }, 0, 60000);
    }

    private void checkUpcomingTasks() {
        long now = System.currentTimeMillis();
        long future = now + (30 * 60 * 1000);

        try {

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (timer != null) {
            timer.cancel();
        }
    }
}