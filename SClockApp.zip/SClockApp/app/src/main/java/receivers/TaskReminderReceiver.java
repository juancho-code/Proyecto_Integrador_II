package receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import utils.NotificationsUtils;

public class TaskReminderReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String taskTitle = intent.getStringExtra("task_title");
        String taskDescription = intent.getStringExtra("task_description");

        NotificationsUtils.showTaskNotification(context, taskTitle, taskDescription);
    }
}
