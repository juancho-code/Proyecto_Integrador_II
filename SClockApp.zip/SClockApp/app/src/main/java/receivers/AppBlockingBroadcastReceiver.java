package receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import utils.NotificationsUtils;

public class AppBlockingBroadcastReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String appName = intent.getStringExtra("app_name");

        if (appName != null) {
            NotificationsUtils.showAppBlockingNotification(context, appName);
        }
    }
}