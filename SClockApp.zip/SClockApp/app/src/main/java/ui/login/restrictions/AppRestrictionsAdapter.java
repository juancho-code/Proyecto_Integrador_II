package ui.login.restrictions;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sclockapp.R;

import java.util.List;

import data.models.RestrictedApp;

public class AppRestrictionsAdapter extends RecyclerView.Adapter<AppRestrictionsAdapter.ViewHolder> {

    private List<RestrictedApp> apps;
    private OnAppDeleteListener deleteListener;

    public interface OnAppDeleteListener {
        void onDelete(RestrictedApp app);
    }

    public AppRestrictionsAdapter(List<RestrictedApp> apps, OnAppDeleteListener deleteListener) {
        this.apps = apps;
        this.deleteListener = deleteListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_app_restriction, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        RestrictedApp app = apps.get(position);
        holder.tvAppName.setText(app.appName);
        holder.tvPackageName.setText(app.packageName);
        holder.switchBlock.setChecked(app.isBlocked);

        holder.btnDelete.setOnClickListener(v -> {
            if (deleteListener != null) {
                deleteListener.onDelete(app);
            }
        });
    }

    @Override
    public int getItemCount() {
        return apps.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvAppName, tvPackageName;
        Switch switchBlock;
        Button btnDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvAppName = itemView.findViewById(R.id.tv_app_name);
            tvPackageName = itemView.findViewById(R.id.tv_package_name);
            switchBlock = itemView.findViewById(R.id.switch_block);
            btnDelete = itemView.findViewById(R.id.btn_delete);
        }
    }
}