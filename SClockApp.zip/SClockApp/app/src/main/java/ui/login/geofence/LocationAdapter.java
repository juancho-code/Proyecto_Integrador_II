package ui.login.geofence;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sclockapp.R;

import java.util.List;

import data.models.Location;

public class LocationAdapter extends RecyclerView.Adapter<LocationAdapter.LocationViewHolder> {

    private List<Location> locations;
    private OnLocationDeleteListener deleteListener;

    public interface OnLocationDeleteListener {
        void onDelete(Location location);
    }

    public LocationAdapter(List<Location> locations, OnLocationDeleteListener deleteListener) {
        this.locations = locations;
        this.deleteListener = deleteListener;
    }

    @NonNull
    @Override
    public LocationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_location, parent, false);
        return new LocationViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LocationViewHolder holder, int position) {
        Location location = locations.get(position);
        holder.tvName.setText(location.name);
        holder.tvCoordinates.setText(String.format("Lat: %.4f, Lon: %.4f",
                location.latitude, location.longitude));
        holder.tvRadius.setText("Radio: " + location.radius + "m");

        holder.btnDelete.setOnClickListener(v -> {
            if (deleteListener != null) {
                deleteListener.onDelete(location);
            }
        });
    }

    @Override
    public int getItemCount() {
        return locations.size();
    }

    public static class LocationViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvCoordinates, tvRadius;
        Button btnDelete;

        public LocationViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tv_location_name);
            tvCoordinates = itemView.findViewById(R.id.tv_coordinates);
            tvRadius = itemView.findViewById(R.id.tv_radius);
            btnDelete = itemView.findViewById(R.id.btn_delete);
        }
    }
}
