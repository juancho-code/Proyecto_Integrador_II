package ui.login.home;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sclockapp.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

import data.db.SClockDatabase;
import data.models.Location;
import data.models.RestrictedApp;
import data.models.Task;
import ui.login.geofence.GeofenceSetupActivity;
import ui.login.geofence.LocationAdapter;
import ui.login.restrictions.AppRestrictionsActivity;
import ui.login.tasks.TaskAdapter;
import ui.login.tasks.TaskScheduleActivity;
import utils.DateTimeUtils;
import utils.NotificationsUtils;
import utils.SharedPreferencesManager;

public class MainActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private TextView tvGreeting, tvActiveRestrictions, tvUpcomingTasks;
    private RecyclerView rvLocations, rvUpcomingTasks;
    private FloatingActionButton fabAddLocation, fabAddTask, fabRestrictions;
    private SClockDatabase database;
    private SharedPreferencesManager preferencesManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        database = SClockDatabase.getInstance(this);
        preferencesManager = new SharedPreferencesManager(this);

        NotificationsUtils.createNotificationChannels(this);

        setupWindowInsets();
        initializeViews();
        setupListeners();
        loadUserData();
    }

    private void setupWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void initializeViews() {
        toolbar = findViewById(R.id.toolbar);
        tvGreeting = findViewById(R.id.tv_greeting);
        tvActiveRestrictions = findViewById(R.id.tv_active_restrictions);
        tvUpcomingTasks = findViewById(R.id.tv_upcoming_tasks);
        rvLocations = findViewById(R.id.rv_locations);
        rvUpcomingTasks = findViewById(R.id.rv_upcoming_tasks);
        fabAddLocation = findViewById(R.id.fab_add_location);
        fabAddTask = findViewById(R.id.fab_add_task);
        fabRestrictions = findViewById(R.id.fab_restrictions);

        rvLocations.setLayoutManager(new LinearLayoutManager(this));
        rvUpcomingTasks.setLayoutManager(new LinearLayoutManager(this));

        setSupportActionBar(toolbar);
        setTitle("SClockApp");
    }

    private void setupListeners() {
        fabAddTask.setOnClickListener(v -> {
            startActivity(new Intent(this, TaskScheduleActivity.class));
        });

        fabAddLocation.setOnClickListener(v -> {
            startActivity(new Intent(this, GeofenceSetupActivity.class));
        });

        fabRestrictions.setOnClickListener(v -> {
            startActivity(new Intent(this, AppRestrictionsActivity.class));
        });
    }

    private void loadUserData() {
        String userName = preferencesManager.getString("user_name", "Usuario");
        tvGreeting.setText("Hola, " + userName);

        int userId = preferencesManager.getInt("user_id", -1);
        if (userId > 0) {
            // Cargar restricciones activas
            List<RestrictedApp> apps = database.restrictedAppDao().getRestrictedAppsByUser(userId);
            tvActiveRestrictions.setText(apps.size() + " aplicaciones restringidas");

            // Cargar próximas tareas
            List<Task> pendingTasks = database.taskDao().getPendingTasksByUser(userId);
            tvUpcomingTasks.setText("Próximas tareas: " + pendingTasks.size());

            // Cargar ubicaciones en RecyclerView
            List<Location> locations = database.locationDao().getLocationsByUser(userId);
            rvLocations.setAdapter(new LocationAdapter(locations, location -> {
                database.locationDao().deleteLocation(location);
                loadUserData();
            }));

            // Cargar tareas en RecyclerView
            rvUpcomingTasks.setAdapter(new TaskAdapter(pendingTasks, task -> {
                database.taskDao().deleteTask(task);
                loadUserData();
            }));
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadUserData();
    }
}