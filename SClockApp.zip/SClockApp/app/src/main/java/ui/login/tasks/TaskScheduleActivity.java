package ui.login.tasks;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sclockapp.R;

import java.util.List;

import data.db.SClockDatabase;
import data.models.Task;
import utils.SharedPreferencesManager;

public class TaskScheduleActivity extends AppCompatActivity {

    private EditText etTaskTitle, etTaskDescription, etTaskTime;
    private Button btnAddTask;
    private RecyclerView recyclerViewTasks;
    private TaskAdapter taskAdapter;
    private SClockDatabase database;
    private SharedPreferencesManager preferencesManager;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tasks);

        database = SClockDatabase.getInstance(this);
        preferencesManager = new SharedPreferencesManager(this);
        userId = preferencesManager.getInt("user_id", -1);

        initializeViews();
        setupListeners();
        loadTasks();
    }

    private void initializeViews() {
        etTaskTitle = findViewById(R.id.et_task_title);
        etTaskDescription = findViewById(R.id.et_task_description);
        etTaskTime = findViewById(R.id.et_task_time);
        btnAddTask = findViewById(R.id.btn_add_task);
        recyclerViewTasks = findViewById(R.id.rv_tasks);

        recyclerViewTasks.setLayoutManager(new LinearLayoutManager(this));
    }

    private void setupListeners() {
        btnAddTask.setOnClickListener(v -> addNewTask());
    }

    private void addNewTask() {
        String title = etTaskTitle.getText().toString().trim();
        String description = etTaskDescription.getText().toString().trim();
        String timeStr = etTaskTime.getText().toString().trim();

        if (title.isEmpty() || description.isEmpty() || timeStr.isEmpty()) {
            Toast.makeText(this, "Por favor completa todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            // Intentar parsear como timestamp en milisegundos
            long scheduledTime = Long.parseLong(timeStr);
            if (scheduledTime <= 0) {
                Toast.makeText(this, "El tiempo debe ser un valor positivo (timestamp en ms)", Toast.LENGTH_SHORT).show();
                return;
            }
            Task task = new Task(title, description, scheduledTime, userId);
            database.taskDao().insertTask(task);

            etTaskTitle.setText("");
            etTaskDescription.setText("");
            etTaskTime.setText("");

            loadTasks();
            Toast.makeText(this, "Tarea creada", Toast.LENGTH_SHORT).show();
        } catch (NumberFormatException e) {
            Toast.makeText(this, "El campo Tiempo debe ser un número (timestamp en ms)", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Error al crear la tarea", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadTasks() {
        if (userId > 0) {
            List<Task> tasks = database.taskDao().getTasksByUser(userId);
            taskAdapter = new TaskAdapter(tasks, task -> deleteTask(task));
            recyclerViewTasks.setAdapter(taskAdapter);
        }
    }

    private void deleteTask(Task task) {
        database.taskDao().deleteTask(task);
        loadTasks();
        Toast.makeText(this, "Tarea eliminada", Toast.LENGTH_SHORT).show();
    }
}