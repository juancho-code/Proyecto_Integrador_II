package ui.login.restrictions;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sclockapp.R;

import java.util.List;

import data.db.SClockDatabase;
import data.models.RestrictedApp;
import utils.SharedPreferencesManager;

public class AppRestrictionsActivity extends AppCompatActivity {

    private EditText etPackageName, etAppName;
    private Button btnAddRestriction;
    private RecyclerView recyclerViewApps;
    private AppRestrictionsAdapter adapter;
    private SClockDatabase database;
    private SharedPreferencesManager preferencesManager;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restrictions);

        database = SClockDatabase.getInstance(this);
        preferencesManager = new SharedPreferencesManager(this);
        userId = preferencesManager.getInt("user_id", -1);

        initializeViews();
        setupListeners();
        loadRestrictions();
    }

    private void initializeViews() {
        etPackageName = findViewById(R.id.et_package_name);
        etAppName = findViewById(R.id.et_app_name);
        btnAddRestriction = findViewById(R.id.btn_add_restriction);
        recyclerViewApps = findViewById(R.id.rv_restricted_apps);

        recyclerViewApps.setLayoutManager(new LinearLayoutManager(this));
    }

    private void setupListeners() {
        btnAddRestriction.setOnClickListener(v -> addRestriction());
    }

    private void addRestriction() {
        String packageName = etPackageName.getText().toString().trim();
        String appName = etAppName.getText().toString().trim();

        if (packageName.isEmpty() || appName.isEmpty()) {
            Toast.makeText(this, "Por favor completa todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        RestrictedApp app = new RestrictedApp(packageName, appName, "", userId);
        database.restrictedAppDao().insertRestrictedApp(app);

        etPackageName.setText("");
        etAppName.setText("");

        loadRestrictions();
        Toast.makeText(this, "Restricción añadida", Toast.LENGTH_SHORT).show();
    }

    private void loadRestrictions() {
        if (userId > 0) {
            List<RestrictedApp> apps = database.restrictedAppDao()
                    .getRestrictedAppsByUser(userId);
            adapter = new AppRestrictionsAdapter(apps, app -> deleteRestriction(app));
            recyclerViewApps.setAdapter(adapter);
        }
    }

    private void deleteRestriction(RestrictedApp app) {
        database.restrictedAppDao().deleteRestrictedApp(app);
        loadRestrictions();
        Toast.makeText(this, "Restricción eliminada", Toast.LENGTH_SHORT).show();
    }
}
