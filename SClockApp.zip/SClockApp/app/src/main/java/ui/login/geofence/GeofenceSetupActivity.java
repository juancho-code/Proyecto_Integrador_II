package ui.login.geofence;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sclockapp.R;

import java.util.List;

import data.db.SClockDatabase;
import data.models.Location;
import utils.SharedPreferencesManager;

public class GeofenceSetupActivity extends AppCompatActivity {

    private EditText etLocationName, etLatitude, etLongitude, etRadius;
    private Button btnAddLocation;
    private RecyclerView recyclerViewLocations;
    private LocationAdapter locationAdapter;
    private SClockDatabase database;
    private SharedPreferencesManager preferencesManager;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_geofence_setup);

        database = SClockDatabase.getInstance(this);
        preferencesManager = new SharedPreferencesManager(this);
        userId = preferencesManager.getInt("user_id", -1);

        initializeViews();
        setupListeners();
        loadLocations();
    }

    private void initializeViews() {
        etLocationName = findViewById(R.id.et_location_name);
        etLatitude = findViewById(R.id.et_latitude);
        etLongitude = findViewById(R.id.et_longitude);
        etRadius = findViewById(R.id.et_radius);
        btnAddLocation = findViewById(R.id.btn_add_location);
        recyclerViewLocations = findViewById(R.id.rv_locations);

        recyclerViewLocations.setLayoutManager(new LinearLayoutManager(this));
    }

    private void setupListeners() {
        btnAddLocation.setOnClickListener(v -> addLocation());
    }

    private void addLocation() {
        String name = etLocationName.getText().toString().trim();
        String latStr = etLatitude.getText().toString().trim();
        String lonStr = etLongitude.getText().toString().trim();
        String radStr = etRadius.getText().toString().trim();

        if (name.isEmpty() || latStr.isEmpty() || lonStr.isEmpty() || radStr.isEmpty()) {
            Toast.makeText(this, "Por favor completa todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double latitude = Double.parseDouble(latStr);
            double longitude = Double.parseDouble(lonStr);
            double radius = Double.parseDouble(radStr);

            Location location = new Location(name, latitude, longitude, radius, userId);
            database.locationDao().insertLocation(location);

            etLocationName.setText("");
            etLatitude.setText("");
            etLongitude.setText("");
            etRadius.setText("");

            loadLocations();
            Toast.makeText(this, "Ubicación añadida", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Error al añadir ubicación", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadLocations() {
        if (userId > 0) {
            List<Location> locations = database.locationDao()
                    .getLocationsByUser(userId);
            locationAdapter = new LocationAdapter(locations, location -> deleteLocation(location));
            recyclerViewLocations.setAdapter(locationAdapter);
        }
    }

    private void deleteLocation(Location location) {
        database.locationDao().deleteLocation(location);
        loadLocations();
        Toast.makeText(this, "Ubicación eliminada", Toast.LENGTH_SHORT).show();
    }
}
