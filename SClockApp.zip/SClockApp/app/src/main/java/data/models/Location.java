package data.models;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;


@Entity(tableName = "locations")
public class Location {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public String name;
    public double latitude;
    public double longitude;
    public double radius;
    public int userId;
    public long createdAt;

    public Location(){}

    @Ignore

    public Location(String name, double latitude, double longitude,double radius, int userId){
        this.name = name;
        this.latitude = latitude;
        this.longitude = longitude;
        this.radius = radius;
        this.userId = userId;
        this.createdAt = System.currentTimeMillis();

    }

    @Ignore
    public Location(int id, String name, double latitude, double longitude, double radius, int userId,long createdAt){
        this.id = id;
        this.name = name ;
        this.latitude = latitude;
        this.longitude = longitude;
        this.radius = radius;
        this.userId = userId;
        this.createdAt = createdAt;
    }

}
