package data.models;


import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;



@Entity(tableName = "users")
public class User {

    @PrimaryKey(autoGenerate = true)
    public int id;

    public String email;
    public String password;
    public String name;
    public String phone;
    public long createdAt;
    public boolean isAdmin;

    public User(){}


    @Ignore
    public User(String email, String password, String name){
        this.email = email;
        this.password = password;
        this.name = name;
        this.createdAt = System.currentTimeMillis();
        this.isAdmin = false;
    }

    @Ignore
    public User(int id, String email, String password, String name, String phone, long createdAt, boolean isAdmin){
        this.id = id;
        this.email = email;
        this.password = password;
        this.name = name;
        this.phone = phone;
        this.createdAt = createdAt;
        this.isAdmin = isAdmin;
    }

}
