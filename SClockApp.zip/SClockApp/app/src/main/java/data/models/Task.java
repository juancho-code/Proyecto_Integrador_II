package data.models;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "tasks")
public class Task {
    @PrimaryKey(autoGenerate = true)
    public int id;

    public String title;
    public String description;
    public long scheduledTime;
    public long createdAt;
    public boolean isCompleted;
    public int userId;

    public Task(){}

    @Ignore
    public Task(String title, String description, long scheduledTime, int userId){
        this.title = title;
        this.description = description;
        this.scheduledTime = scheduledTime;
        this.userId = userId;
        this.createdAt = System.currentTimeMillis();
        this.isCompleted = false;


    }

    @Ignore
    public Task(int id, String title, String description, long scheduledTime, long createdAt, boolean isCompleted, int userId){

        this.id = id;
        this.title = title;
        this.description = description;
        this.scheduledTime = scheduledTime;
        this.createdAt = createdAt;
        this.isCompleted = isCompleted;
        this.userId = userId;
    }
}
