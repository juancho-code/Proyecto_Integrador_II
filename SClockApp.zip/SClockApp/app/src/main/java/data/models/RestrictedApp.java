package data.models;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "restricted_apps")
public class RestrictedApp {
    @PrimaryKey(autoGenerate = true)
    public int id;

    public String packageName;
    public String appName;
    public String appIcon;
    public int userId;
    public long createdAt;
    public boolean isBlocked;

    public RestrictedApp() {}

    @Ignore
    public RestrictedApp(String packageName, String appName, String appIcon, int userId) {
        this.packageName = packageName;
        this.appName = appName;
        this.appIcon = appIcon;
        this.userId = userId;
        this.createdAt = System.currentTimeMillis();
        this.isBlocked = false;
    }

    @Ignore
    public RestrictedApp(int id, String packageName, String appName, String appIcon, int userId, long createdAt, boolean isBlocked) {
        this.id = id;
        this.packageName = packageName;
        this.appName = appName;
        this.appIcon = appIcon;
        this.userId = userId;
        this.createdAt = createdAt;
        this.isBlocked = isBlocked;
    }
}