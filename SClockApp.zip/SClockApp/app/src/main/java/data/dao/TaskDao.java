package data.dao;


import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import data.models.Task;

@Dao
public interface TaskDao {

    @Insert
    long insertTask(Task task);

    @Update
    void updateTask(Task task);

    @Delete
    void deleteTask(Task task);

    @Query("select * from tasks where id = :taskId")
    Task getTaskById(int taskId);

    @Query("select * from tasks where userId = :userId order by scheduledTime desc")
    List <Task> getTasksByUser(int userId);

    @Query("select * from tasks where userId = :userId and isCompleted = 0 order by scheduledTime asc")
    List <Task> getPendingTasksByUser(int userId);

    @Query("select * from tasks where userId = :userId and isCompleted = 1 order by scheduledTime desc")
    List <Task> getCompletedTasksByUser(int userId);

    @Query("select * from tasks where scheduledTime between :startTime and :endTime")
    List <Task> getTasksByDateRange(long startTime, long endTime);

    @Query("update tasks set isCompleted = 1 where id = :taskId")
    void completedTask(int taskId);

    @Query("delete from tasks where id = :taskId")
    void deleteTaskById(int taskId);

    @Query("delete from tasks where userId = :userId")
    void deleteTasksByUser(int userId);
}

