package data.dao;


import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import data.models.Location;

@Dao
public interface LocationDao {
    @Insert
    long insertLocation(Location location);

    @Update
    void updateLocation(Location location);

    @Delete
    void deleteLocation(Location location);

    @Query("select * from locations where id = :locationId")
    Location getLocationById(int locationId);

    @Query("select * from locations where userId = :userId")
    List <Location> getLocationsByUser(int userId);

    @Query("select * from locations")
    List <Location> getAllLocations();

    @Query("select * from locations where name like '%' || :searchQuery || '%' ")
    List <Location> searchLocations(String searchQuery);

    @Query("delete from locations where id = :locationId")
    void deleteLocationById(int locationId);

    @Query("delete from locations where userId = :userId")
    void deleteLocationsByUser(int userId);
}
