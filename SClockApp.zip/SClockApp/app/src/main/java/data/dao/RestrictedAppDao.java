package data.dao;


import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import data.models.RestrictedApp;

@Dao
public interface RestrictedAppDao {
    @Insert
    long insertRestrictedApp(RestrictedApp restrictedApp);

    @Update
    void updateRestrictedApp(RestrictedApp restrictedApp);

    @Delete
    void deleteRestrictedApp(RestrictedApp restrictedApp);

    @Query("select * from restricted_apps where id = :appId")
    RestrictedApp getRestrictedAppById(int appId);

    @Query("SELECT * FROM restricted_apps WHERE userId = :userId")
    List<RestrictedApp> getRestrictedAppsByUser(int userId);

    @Query("SELECT * FROM restricted_apps WHERE userId = :userId AND isBlocked = 1")
    List<RestrictedApp> getBlockedAppsByUser(int userId);

    @Query("SELECT * FROM restricted_apps WHERE packageName = :packageName")
    RestrictedApp getRestrictedAppByPackage(String packageName);

    @Query("SELECT * FROM restricted_apps WHERE packageName = :packageName AND userId = :userId")
    RestrictedApp getUserRestrictedApp(String packageName, int userId);

    @Query("UPDATE restricted_apps SET isBlocked = :isBlocked WHERE id = :appId")
    void updateBlockStatus(int appId, boolean isBlocked);

    @Query("DELETE FROM restricted_apps WHERE id = :appId")
    void deleteRestrictedAppById(int appId);

    @Query("DELETE FROM restricted_apps WHERE userId = :userId")
    void deleteRestrictedAppsByUser(int userId);}
