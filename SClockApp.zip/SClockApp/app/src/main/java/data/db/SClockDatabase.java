package data.db;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import data.dao.LocationDao;
import data.dao.RestrictedAppDao;
import data.dao.TaskDao;
import data.dao.UserDao;
import data.models.Location;
import data.models.RestrictedApp;
import data.models.Task;
import data.models.User;

@Database(
        entities = {User.class, Task.class, Location.class, RestrictedApp.class},
        version = 1,
        exportSchema = false
)
public abstract class SClockDatabase extends RoomDatabase {
    private static final String DATABASE_NAME = "sclock_db";
    private static volatile SClockDatabase instance;

    public abstract UserDao userDao();
    public abstract TaskDao taskDao();
    public abstract LocationDao locationDao();
    public abstract RestrictedAppDao restrictedAppDao();

    public static SClockDatabase getInstance(Context context) {
        if (instance == null) {
            synchronized (SClockDatabase.class) {
                if (instance == null) {
                    instance = Room.databaseBuilder(
                                    context.getApplicationContext(),
                                    SClockDatabase.class,
                                    DATABASE_NAME
                            )
                            .allowMainThreadQueries()
                            .build();
                }
            }
        }
        return instance;
    }
}