package data.db;

public class PostgreSQLConfig {


    private static final String DB_HOST = "localhost";
    private static final int DB_PORT = 5432;
    private static final String DB_NAME = "sclock_db";
    private static final String DB_USER = "postgres";
    private static final String DB_PASSWORD = "postgres";


    private static final String DB_DRIVER = "org.postgresql.Driver";

    private static final int CONNECTION_TIMEOUT = 30;

    private static final int STATEMENT_TIMEOUT = 60000;
    private static final int MAX_CONNECTIONS = 20;


    public static String getJdbcUrl() {
        return "jdbc:postgresql://" + DB_HOST + ":" + DB_PORT + "/" + DB_NAME;
    }

    public static String getJdbcUrlWithParams() {
        return getJdbcUrl() + "?user=" + DB_USER + "&password=" + DB_PASSWORD;
    }


    public static String getHost() {
        return DB_HOST;
    }

    public static int getPort() {
        return DB_PORT;
    }

    public static String getDatabaseName() {
        return DB_NAME;
    }

    public static String getUsername() {
        return DB_USER;
    }

    public static String getPassword() {
        return DB_PASSWORD;
    }

    public static String getDriver() {
        return DB_DRIVER;
    }

    public static int getConnectionTimeout() {
        return CONNECTION_TIMEOUT;
    }

    public static int getStatementTimeout() {
        return STATEMENT_TIMEOUT;
    }

    public static int getMaxConnections() {
        return MAX_CONNECTIONS;
    }


    public static boolean validateConfig() {
        try {
            Class.forName(DB_DRIVER);
            return true;
        } catch (ClassNotFoundException e) {
            System.err.println("PostgreSQL driver no encontrado: " + e.getMessage());
            return false;
        }
    }


    public static String getConfigInfo() {
        return "PostgreSQL Configuration:\n" +
                "Host: " + DB_HOST + "\n" +
                "Port: " + DB_PORT + "\n" +
                "Database: " + DB_NAME + "\n" +
                "Username: " + DB_USER + "\n" +
                "Max Connections: " + MAX_CONNECTIONS + "\n" +
                "Connection Timeout: " + CONNECTION_TIMEOUT + " seconds\n" +
                "JDBC URL: " + getJdbcUrl();
    }


    public static class ConfigBuilder {
        private String host = DB_HOST;
        private int port = DB_PORT;
        private String dbName = DB_NAME;
        private String username = DB_USER;
        private String password = DB_PASSWORD;
        private int maxConnections = MAX_CONNECTIONS;

        public ConfigBuilder setHost(String host) {
            this.host = host;
            return this;
        }

        public ConfigBuilder setPort(int port) {
            this.port = port;
            return this;
        }

        public ConfigBuilder setDatabaseName(String dbName) {
            this.dbName = dbName;
            return this;
        }

        public ConfigBuilder setUsername(String username) {
            this.username = username;
            return this;
        }

        public ConfigBuilder setPassword(String password) {
            this.password = password;
            return this;
        }

        public ConfigBuilder setMaxConnections(int maxConnections) {
            this.maxConnections = maxConnections;
            return this;
        }

        public String build() {
            return "jdbc:postgresql://" + host + ":" + port + "/" + dbName +
                    "?user=" + username + "&password=" + password +
                    "&ssl=true&sslmode=require";
        }

        public String buildWithoutSSL() {
            return "jdbc:postgresql://" + host + ":" + port + "/" + dbName +
                    "?user=" + username + "&password=" + password;
        }
    }

    public static class ConnectionProperties {
        private String url;
        private String username;
        private String password;

        public ConnectionProperties(String url, String username, String password) {
            this.url = url;
            this.username = username;
            this.password = password;
        }

        public String getUrl() {
            return url;
        }

        public String getUsername() {
            return username;
        }

        public String getPassword() {
            return password;
        }
    }


    public static ConnectionProperties getConnectionProperties() {
        return new ConnectionProperties(
                getJdbcUrl(),
                DB_USER,
                DB_PASSWORD
        );
    }
}