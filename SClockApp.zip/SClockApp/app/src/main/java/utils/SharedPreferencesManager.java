package utils;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;

import java.io.IOException;
import java.security.GeneralSecurityException;

public class SharedPreferencesManager {

    private static final String PREFS_NAME = "sclock_prefs";
    private SharedPreferences sharedPreferences;

    public SharedPreferencesManager (Context context) {
        try {
            MasterKey masterKey = new MasterKey.Builder(context)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build();

            sharedPreferences = EncryptedSharedPreferences.create(
                    context,
                    PREFS_NAME,
                    masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            );
        } catch (GeneralSecurityException | IOException e){
            e.printStackTrace();
        }
    }


    public void saveString(String key, String value){
        if(sharedPreferences != null){
            sharedPreferences.edit().putString(key,value).apply();
        }
    }
    public void saveInt(String key, int value){
        if(sharedPreferences != null ){
            sharedPreferences.edit().putInt(key, value).apply();
        }
    }

    public void saveBoolean(String key, boolean value){
        if(sharedPreferences != null){
            sharedPreferences.edit().putBoolean(key, value).apply();
        }
    }

    public void saveLong(String key, long value){
        if(sharedPreferences !=null){
            sharedPreferences.edit().putLong(key, value).apply();
        }
    }

    public String getString(String key, String defaultValue){
        if(sharedPreferences == null) return defaultValue;
        return sharedPreferences.getString(key,defaultValue);
    }

    public int getInt(String key, int defaultValue){
        if (sharedPreferences == null) return defaultValue;
        return sharedPreferences.getInt(key, defaultValue);
    }

    public boolean getBoolean(String key, boolean defaultValue){
        if(sharedPreferences == null) return defaultValue;
        return sharedPreferences.getBoolean(key, defaultValue);
    }

    public long getLong(String key, long defaultValue){
        if (sharedPreferences == null) return defaultValue;
        return sharedPreferences.getLong(key, defaultValue);
    }

    public void remove(String key){
        if (sharedPreferences != null){
            sharedPreferences.edit().remove(key).apply();
        }
    }

    public void clear(){
        if (sharedPreferences != null){
            sharedPreferences.edit().clear().apply();
        }
    }

    public boolean contains(String key){
        if (sharedPreferences == null) return false;
        return sharedPreferences.contains(key);
    }
}