package utils;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import com.example.sclockapp.R;

public class NotificationsUtils {

    public static final String TASK_CHANNEL_ID = "task_notifications";
    public static final String GEOFENCE_CHANNEL_ID = "geofence_notifications";
    public static final String APP_BLOCKING_CHANNEL_ID = "app_blocking_notifications";

    public static void createNotificationChannels(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager notificationManager =
                    context.getSystemService(NotificationManager.class);

            
            NotificationChannel taskChannel = new NotificationChannel(
                    TASK_CHANNEL_ID,
                    "Notificaciones de Tareas",
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            taskChannel.setDescription("Notificaciones de recordatorios de tareas");
            notificationManager.createNotificationChannel(taskChannel);


            NotificationChannel geofenceChannel = new NotificationChannel(
                    GEOFENCE_CHANNEL_ID,
                    "Notificaciones de Ubicación",
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            geofenceChannel.setDescription("Notificaciones de geofence");
            notificationManager.createNotificationChannel(geofenceChannel);


            NotificationChannel appBlockingChannel = new NotificationChannel(
                    APP_BLOCKING_CHANNEL_ID,
                    "Bloqueo de Aplicaciones",
                    NotificationManager.IMPORTANCE_HIGH
            );
            appBlockingChannel.setDescription("Notificaciones de bloqueo de aplicaciones");
            notificationManager.createNotificationChannel(appBlockingChannel);
        }
    }

    public static void showTaskNotification(Context context, String title, String message) {
        NotificationManager notificationManager;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            notificationManager = context.getSystemService(NotificationManager.class);
        } else {
            notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        }

        if (notificationManager == null) return;

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, TASK_CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_task)
                .setContentTitle(title)
                .setContentText(message)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        notificationManager.notify((int) System.currentTimeMillis(), builder.build());
    }

    public static void showGeofenceNotification(Context context, String title, String message) {
        NotificationManager notificationManager;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            notificationManager = context.getSystemService(NotificationManager.class);
        } else {
            notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        }

        if (notificationManager == null) return;

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, GEOFENCE_CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_location)
                .setContentTitle(title)
                .setContentText(message)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        notificationManager.notify((int) System.currentTimeMillis(), builder.build());
    }

    public static void showAppBlockingNotification(Context context, String appName) {
        NotificationManager notificationManager;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            notificationManager = context.getSystemService(NotificationManager.class);
        } else {
            notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        }

        if (notificationManager == null) return;

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, APP_BLOCKING_CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_block)
                .setContentTitle("Aplicación Bloqueada")
                .setContentText(appName + " está bloqueada")
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH);

        notificationManager.notify((int) System.currentTimeMillis(), builder.build());
    }
}