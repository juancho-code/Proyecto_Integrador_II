package utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class DateTimeUtils  {

    public static String formatDate(long timestamp) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        return sdf.format(new Date(timestamp));
    }

    public static String formatTime(long timestamp) {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
        return sdf.format(new Date(timestamp));
    }

    public static String formatDateTime(long timestamp) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault());
        return sdf.format(new Date(timestamp));
    }

    public static String getRelativeTime(long timestamp) {
        long now = System.currentTimeMillis();
        long diff = now - timestamp;

        long seconds = diff / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;
        long days = hours / 24;

        if (seconds < 60) {
            return "hace " + seconds + " segundo(s)";
        } else if (minutes < 60) {
            return "hace " + minutes + " minuto(s)";
        } else if (hours < 24) {
            return "hace " + hours + " hora(s)";
        } else if (days < 7) {
            return "hace " + days + " día(s)";
        } else {
            return formatDate(timestamp);
        }
    }

    public static long getTodayStartTime() {
        long now = System.currentTimeMillis();
        return (now / 86400000) * 86400000;
    }

    public static long getTodayEndTime() {
        return getTodayStartTime() + 86399999;
    }

    public static long getWeekStartTime() {
        long now = System.currentTimeMillis();
        long todayStart = getTodayStartTime();
        long dayOfWeek = ((todayStart / 86400000) + 4) % 7;
        return todayStart - (dayOfWeek * 86400000);
    }

    public static long getMonthStartTime() {
        long now = System.currentTimeMillis();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-01", Locale.getDefault());
        try {
            Date date = sdf.parse(formatDate(now).substring(0, 7) + "-01");
            return date.getTime();
        } catch (Exception e) {
            return now;
        }
    }
}
